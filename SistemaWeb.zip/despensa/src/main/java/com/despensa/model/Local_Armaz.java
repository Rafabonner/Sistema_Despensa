package com.despensa.model;

public class Local_Armaz {

}
